import re
from nltk.corpus import stopwords
from nltk.tokenize import RegexpTokenizer

def preprocess_text(text):
    # Lowercase the text
    text = text.lower()
    
    # Remove non-letter characters
    text = re.sub(r'[^a-z\s]', '', text)
    
    # Tokenize using a regex (bypasses punkt)
    tokenizer = RegexpTokenizer(r'\b[a-z]{2,}\b')  # only alphabetic words, min 2 chars
    tokens = tokenizer.tokenize(text)
    
    # Remove stopwords
    tokens = [word for word in tokens if word not in stopwords.words('english')]
    
    # Rejoin into cleaned string
    return ' '.join(tokens)
