from extract_text import extract_text_from_pdf
from preprocess import preprocess_text
from predict import predict_personality

if __name__ == '__main__':
    path_to_cv = 'data/sample_cv.pdf'

    raw_text = extract_text_from_pdf(path_to_cv)
    cleaned_text = preprocess_text(raw_text)
    personality = predict_personality(cleaned_text)

    print("Predicted Personality:", personality)

    with open('output/result.txt', 'w') as f:
        f.write(f'Predicted Personality: {personality}')
