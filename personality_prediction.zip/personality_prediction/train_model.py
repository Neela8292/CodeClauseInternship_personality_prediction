from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.naive_bayes import MultinomialNB
from sklearn.pipeline import Pipeline
import pandas as pd
import joblib

def train_model():
    # Simulated dataset (replace with real one)
    data = {
        'cv_text': [
            "Experienced software engineer with leadership and public speaking",
            "Quiet, detail-oriented researcher with strong data analysis skills",
        ],
        'personality': ['Extrovert', 'Introvert']
    }

    df = pd.DataFrame(data)

    pipeline = Pipeline([
        ('tfidf', TfidfVectorizer()),
        ('clf', MultinomialNB())
    ])

    pipeline.fit(df['cv_text'], df['personality'])

    joblib.dump(pipeline, 'models/model.pkl')
    print("Model trained and saved.")

if __name__ == '__main__':
    train_model()
