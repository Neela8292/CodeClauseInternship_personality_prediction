import joblib

def predict_personality(text):
    model = joblib.load('models/model.pkl')
    prediction = model.predict([text])
    return prediction[0]
